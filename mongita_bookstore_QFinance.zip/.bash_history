python3 app.py
.exit
.quit
.kill
kill
exit
