from flask import Flask, render_template, request, redirect, url_for
from mongita import MongitaClientDisk
import os

app = Flask(__name__)


# Mongita Setup (local embedded NoSQL DB)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
client = MongitaClientDisk(os.path.join(BASE_DIR, "mongita_data"))

db = client.bookstore
category_col = db.category
book_col = db.book

def get_categories():
    """All categories sorted by name (mirrors ORDER BY categoryName)."""
    cats = list(category_col.find())
    return sorted(cats, key=lambda c: c["categoryName"])


def get_next_book_id():
    """Auto-increment for bookId, since Mongita has no AUTOINCREMENT."""
    books = list(book_col.find())
    if not books:
        return 1
    return max(b["bookId"] for b in books) + 1


# Splash
@app.route("/", methods=["GET"])
def splash():
    return render_template("splash.html")

# Home
@app.route("/home", methods=["GET"])
def home():
    categories = get_categories()
    return render_template("index.html", categories=categories)

# Category
@app.route("/category", methods=["GET"])
def category():
    category_id = request.args.get("categoryId", type=int)

    categories = get_categories()
    selected_category = category_col.find_one({"categoryId": category_id})

    books = list(book_col.find({"categoryId": category_id}))
    books = sorted(books, key=lambda b: b["title"])

    return render_template(
        "category.html",
        categories=categories,
        selectedCategory=selected_category,
        books=books,
        searchTerm=None,
        nothingFound=False,
    )


# ------------------------------------------
# /search — Title search (case-insensitive substring)
# ------------------------------------------
@app.route("/search", methods=["POST"])
def search():
    term = request.form.get("search", "").strip()

    categories = get_categories()

    term_lower = term.lower()
    books = [b for b in book_col.find() if term_lower in b["title"].lower()]
    books = sorted(books, key=lambda b: b["title"])

    return render_template(
        "category.html",
        categories=categories,
        selectedCategory=None,
        books=books,
        searchTerm=term,
        nothingFound=(len(books) == 0),
    )


# ------------------------------------------
# /book — Book detail page
# ------------------------------------------
@app.route("/book", methods=["GET"])
def book_detail():
    book_id = request.args.get("bookId", type=int)

    categories = get_categories()
    book = book_col.find_one({"bookId": book_id})

    # Manual "JOIN" — attach categoryName onto the book doc.
    if book:
        cat = category_col.find_one({"categoryId": book["categoryId"]})
        book = dict(book)
        book["categoryName"] = cat["categoryName"] if cat else ""

    return render_template("book_detail.html", book=book, categories=categories)


# ------------------------------------------
# /add-book — Insert a new book
# ------------------------------------------
@app.route("/add-book", methods=["GET", "POST"])
def add_book():
    categories = get_categories()

    if request.method == "POST":
        title = request.form.get("title")
        author = request.form.get("author")
        isbn = request.form.get("isbn")
        price = request.form.get("price", type=float)
        image = request.form.get("image")
        category_id = request.form.get("categoryId", type=int)

        new_book = {
            "bookId": get_next_book_id(),
            "categoryId": category_id,
            "title": title,
            "author": author,
            "isbn": isbn,
            "price": price,
            "image": image,
            "readNow": 0,
        }
        book_col.insert_one(new_book)
        return redirect(url_for("home"))

    return render_template("add_book.html", categories=categories)


# ------------------------------------------
# /edit-book — Edit an existing book
# ------------------------------------------
@app.route("/edit-book", methods=["GET", "POST"])
def edit_book():
    book_id = request.args.get("bookId", type=int)
    book = book_col.find_one({"bookId": book_id})

    if not book:
        return render_template("error.html", error="Book not found"), 404

    categories = get_categories()

    if request.method == "POST":
        title = request.form.get("title")
        author = request.form.get("author")
        isbn = request.form.get("isbn")
        price = request.form.get("price", type=float)
        image = request.form.get("image")
        category_id = request.form.get("categoryId", type=int)
        read_now = request.form.get("readNow", type=int) or 0

        book_col.update_one(
            {"bookId": book_id},
            {"$set": {
                "categoryId": category_id,
                "title": title,
                "author": author,
                "isbn": isbn,
                "price": price,
                "image": image,
                "readNow": read_now,
            }}
        )
        return redirect(url_for("book_detail", bookId=book_id))

    return render_template("edit_book.html", book=book, categories=categories)


# ------------------------------------------
# /delete-book — Delete a book
# ------------------------------------------
@app.route("/delete-book", methods=["POST"])
def delete_book():
    book_id = request.args.get("bookId", type=int)
    book_col.delete_one({"bookId": book_id})
    return redirect(url_for("home"))


# ------------------------------------------
# /author-search — Search by author
# ------------------------------------------
@app.route("/author-search", methods=["GET", "POST"])
def author_search():
    categories = get_categories()
    books = []
    search_term = None
    nothing_found = False

    if request.method == "POST":
        search_term = request.form.get("author", "").strip()
        term_lower = search_term.lower()
        books = [b for b in book_col.find() if term_lower in b["author"].lower()]
        books = sorted(books, key=lambda b: b["author"])
        nothing_found = (len(books) == 0)

    return render_template(
        "author_search.html",
        categories=categories,
        books=books,
        searchTerm=search_term,
        nothingFound=nothing_found,
    )


# ------------------------------------------
# Error handler
# ------------------------------------------
@app.errorhandler(Exception)
def handle_error(e):
    return render_template("error.html", error=e), 500


# ------------------------------------------
# Run
# ------------------------------------------
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port, debug=True)
