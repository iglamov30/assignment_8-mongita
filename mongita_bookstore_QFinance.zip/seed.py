import os
from mongita import MongitaClientDisk
import json

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
client = MongitaClientDisk(os.path.join(BASE_DIR, "mongita_data"))

db = client.bookstore
category_col = db.category
book_col = db.book

# Reset collections
category_col.delete_many({})
book_col.delete_many({})

# Categories
category_col.insert_many([
    {"categoryId": 1, "categoryName": "General Quant Finance Reading",         "categoryImage": "general.jpg"},
    {"categoryId": 2, "categoryName": "Interview Preparation",                 "categoryImage": "interview.png"},
    {"categoryId": 3, "categoryName": "Quantitative/High-Frequency Trading",   "categoryImage": "quant.jpeg"},
    {"categoryId": 4, "categoryName": "Econometrics",                          "categoryImage": "econometrics.jpg"},
    {"categoryId": 5, "categoryName": "Mathematical Finance",                  "categoryImage": "mathematical_finance.jpg"},
])

# Books
book_col.insert_many([
    {"bookId": 1,  "categoryId": 1, "title": "The Big Short: Inside the Doomsday Machine",                                              "author": "Michael Lewis",          "isbn": "9780678054749", "price": 40.99, "image": "big_short.jpg",            "readNow": 1},
    {"bookId": 2,  "categoryId": 1, "title": "Liar's Poker",                                                                              "author": "Michael Lewis",          "isbn": "9781250293564", "price": 29.99, "image": "liars_poker.jpg",          "readNow": 0},
    {"bookId": 3,  "categoryId": 1, "title": "When Genius Failed: The Rise and Fall of Long-Term Capital Management",                    "author": "Roger Lowenstein",       "isbn": "9782594036682", "price": 26.99, "image": "genius_failed.jpg",        "readNow": 0},
    {"bookId": 4,  "categoryId": 1, "title": "My Life as a Quant: Reflections on Physics and Finance",                                   "author": "Emanuel Derman",         "isbn": "9780167920551", "price": 42.99, "image": "life_as_quant.jpg",        "readNow": 0},

    {"bookId": 5,  "categoryId": 2, "title": "Heard on The Street: Quantitative Questions from Wall Street Job Interviews",              "author": "Timothy Crack",          "isbn": "9780693523054", "price": 44.99, "image": "heard_on.jpg",             "readNow": 1},
    {"bookId": 6,  "categoryId": 2, "title": "Frequently Asked Questions in Quantitative Finance",                                       "author": "Paul Wilmott",           "isbn": "9780882849163", "price": 16.99, "image": "freq_asked.jpg",           "readNow": 1},
    {"bookId": 7,  "categoryId": 2, "title": "Quant Job Interview Questions And Answers",                                                "author": "Mark Joshi",             "isbn": "9781119572028", "price": 22.99, "image": "q_and_a.jpg",              "readNow": 1},
    {"bookId": 8,  "categoryId": 2, "title": "A Practical Guide To Quantitative Finance Interviews",                                     "author": "Xinfeng Zhou",           "isbn": "9781263060380", "price": 39.99, "image": "practical_guide.jpg",      "readNow": 0},

    {"bookId": 9,  "categoryId": 3, "title": "Trading Systems: A New Approach to System Development and Portfolio Optimisation",         "author": "Emilio Tomasini",        "isbn": "9780793523054", "price": 44.99, "image": "trading_systems.jpeg",     "readNow": 1},
    {"bookId": 10, "categoryId": 3, "title": "Quantitative Trading and Money Management, Revised Edition",                               "author": "Fred Gehm",              "isbn": "9780882896163", "price": 16.99, "image": "money_management.jpg",     "readNow": 1},
    {"bookId": 11, "categoryId": 3, "title": "Algorithmic Trading and DMA: An introduction to direct access trading strategies",         "author": "Barry Johnson",          "isbn": "9780119575528", "price": 22.99, "image": "dma.jpg",                  "readNow": 1},
    {"bookId": 12, "categoryId": 3, "title": "Dynamic Hedging: Managing Vanilla and Exotic Options",                                     "author": "Nassim Nicholas Taleb",  "isbn": "9780634000380", "price": 19.99, "image": "vanilla_exotic.jpg",       "readNow": 0},

    {"bookId": 13, "categoryId": 4, "title": "Introductory Econometrics for Finance",                                                    "author": "Chris Brooks",           "isbn": "9780713523054", "price": 64.99, "image": "intro_econometrics.jpg",   "readNow": 1},
    {"bookId": 14, "categoryId": 4, "title": "Econometric Analysis",                                                                     "author": "William Greene",         "isbn": "9781682846163", "price": 16.95, "image": "econometric_analysis.jpeg","readNow": 1},
    {"bookId": 15, "categoryId": 4, "title": "Time Series Analysis",                                                                     "author": "James Douglas Hamilton", "isbn": "9781459575528", "price": 52.90, "image": "practical_guide.jpg",      "readNow": 1},
    {"bookId": 16, "categoryId": 4, "title": "Analysis of Financial Time Series",                                                        "author": "Ruey S. Tsay",           "isbn": "9786634060380", "price": 34.99, "image": "fin_time_series.jpeg",     "readNow": 0},

    {"bookId": 17, "categoryId": 5, "title": "Options, Futures, and Other Derivatives and DerivaGem CD Package (8th Edition)",           "author": "John Hull",              "isbn": "9780714523054", "price": 41.59, "image": "options_futures.jpeg",     "readNow": 1},
    {"bookId": 18, "categoryId": 5, "title": "A Primer For The Mathematics Of Financial Engineering, Second Edition",                    "author": "Dan Stefanica",          "isbn": "9780882636163", "price": 16.39, "image": "solutions_manual.jpg",     "readNow": 1},
    {"bookId": 19, "categoryId": 5, "title": "Solutions Manual - A Primer For The Mathematics Of Financial Engineering, Second Edition", "author": "Dan Stefanica",          "isbn": "9791119575528", "price": 22.19, "image": "solutions_manual.jpg",     "readNow": 1},
    {"bookId": 20, "categoryId": 5, "title": "Paul Wilmott on Quantitative Finance 3 Volume Set (2nd Edition)",                          "author": "Paul Wilmott",           "isbn": "9780634560380", "price": 39.85, "image": "paul_wilmott.jpg",         "readNow": 0},
])

print(f"Seeded {category_col.count_documents({})} categories and {book_col.count_documents({})} books.")

def export_collection(collection, filename):
    docs = list(collection.find())
    for d in docs:
        d.pop("_id", None)
    path = os.path.join(BASE_DIR, filename)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(docs, f, indent=2, ensure_ascii=False)
    print(f"Exported {len(docs)} documents to {filename}")


export_collection(category_col, "categories.json")
export_collection(book_col, "books.json")
